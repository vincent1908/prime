You need to add JUNIT library to the project/Add TestNG folder to eclipse
Add project jars from LIB folder
C:\Selenium\repository\ECFramework


Selenium Grid 
#############

java -jar -- drag n drop selenium jar-- -role hub
http://localhost:4444/grid/console

java -jar selenium-server-standalone-2.53.2.jar -role node -hub http://localhost:4444/grid/register

Pre Requisite before execution:
1.Run Winium.Desktop.Driver.exe from lib folder


For TestNG run from cmd
java -cp C:\Selenium\repository\ECFramework\lib\*;C:\Selenium\repository\ECFramework\bin org.testng.TestNG testng.xml
cd C:\Selenium\repository\ECFramework
174b2429460a4a70b7c867d83fcfdb70

Team CapG