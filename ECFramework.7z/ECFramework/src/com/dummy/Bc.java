package com.dummy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.entercard.framework.P;

public class Bc extends P {

	public static void main(String[] args) {

		setUpDB();
		runQuery("SELECT * from CACCOUNTS WHERE stgeneral in ('CLSD','DCAC')AND ROWNUM <= 1");
		getAccountNumberQuery();
		closeDB();

		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\repository\\ECFramework\\lib\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(
				"http://cabhishekg:Delhi110019@ecwvp3web03t.ectest.local/PRMAD05T/prime/WebApplications/CustomerServices/Default.aspx");

		driver.switchTo().frame(0);
		driver.findElement(By.xpath(".//*[@id='optNumber_1']")).click();
		// driver.findElement(By.xpath(".//*[@id='AccNumberTextBox']")).sendKeys("4581990000005229");
		driver.findElement(By.xpath(".//*[@id='AccNumberTextBox']")).sendKeys(accNum);

		driver.findElement(By.xpath(".//*[@id='btnFind']")).click();

		driver.quit();

		System.out.println(accNum);

	}

}
