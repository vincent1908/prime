package com.dummy;

import org.testng.annotations.Test;

public class CallParamMethod {
	
	@Test
	public void callAdd(){
		
		ParamMethod.add(10, 20);
		
	}

}
