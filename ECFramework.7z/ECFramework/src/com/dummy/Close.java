package com.dummy;

import org.testng.annotations.Test;

import com.entercard.pages.AccountStatementDetailsPage;
import com.entercard.pages.CustomerServices;
import com.entercard.pages.FinancialAccountsDetail;
import com.entercard.utilities.BrowserClass;
import com.entercard.utilities.ConfigReader;
import com.entercard.utilities.DBConnection;
import com.entercard.utilities.ProcessQuery;

public class Close {
	@Test
	public void abc() throws Exception {
		DBConnection.setUpDB(); // Parametised
		DBConnection.runQuery(ConfigReader.prop.getProperty("SecondTestCaseB"));
		ProcessQuery.getAccountNumberQuery(); // Parametised
		DBConnection.closeDB();

		BrowserClass.openBrowser();
		BrowserClass.loadPrimeWebApplication();// parametrised
		CustomerServices.accountSearch();
		//FinancialAccountsDetail.StatementNormCard();
		AccountStatementDetailsPage.cyclingTab();
		BrowserClass.closeBrowser();

	}
	
	public void def(){
		/* AdminJobs.loginPrJobAdmin();
				 AdminJobs.enterAdminUserId();
				 AdminJobs.enterAdminPassWord();
				 AdminJobs.enterAdminInstitution();
				 AdminJobs.submitAdminActions();*/
	}
}
