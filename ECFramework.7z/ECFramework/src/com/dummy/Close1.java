package com.dummy;

import org.testng.annotations.Test;

import com.entercard.pages.AccountStatementDetailsPage;
import com.entercard.pages.CustomerServices;
import com.entercard.utilities.BrowserClass;
import com.entercard.utilities.ConfigReader;
import com.entercard.utilities.DBConnection;
import com.entercard.utilities.ProcessQuery;

public class Close1 {
	
	ConfigReader configRead;
	@Test
	public void abc() throws Exception {
		configRead = new ConfigReader();
		
		BrowserClass.openBrowser();
		BrowserClass.loadPrimeWebApplication1(ConfigReader.prop.getProperty("PrimeDefault"));
		BrowserClass.closeBrowser();

	}
	

}
