/**
 * 
 */
package com.dummy;

import org.openqa.selenium.WebDriver;

/**
 * @author cgregami
 *
 */

import org.testng.annotations.Test;

import com.entercard.framework.DatabaseConnection;
import com.entercard.framework.LoadBrowser;
import com.entercard.framework.LoadPropertyFile;
import com.entercard.pages.AccountStatementDetailsPage;
import com.entercard.pages.CustomerServices;
import com.entercard.pages.FinancialAccountsDetail;
import com.entercard.utilities.AdminJobs;
import com.entercard.utilities.BrowserClass;
import com.entercard.utilities.ConfigReader;
import com.entercard.utilities.DBConnection;
import com.entercard.utilities.ProcessQuery;

@SuppressWarnings("unused")
public class CompleteFlow extends LoadBrowser{

	public CompleteFlow(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	/*
	 * ATC001 Verify that the statement is not generated for Close / DCAC
	 * accounts.
	 */

	@Test
	public static void testingFlow1() throws Exception {

		// Step 1-4

		DBConnection.setUpDB();
		DBConnection.runQuery(ConfigReader.prop.getProperty("FirstTestCase"));
		ProcessQuery.getAccountNumberQuery();
		DBConnection.closeDB();

		// Step 5-9

//		AdminJobs.loginPrJobAdmin();
//		AdminJobs.enterAdminUserId();
//		AdminJobs.enterAdminPassWord();
//		AdminJobs.enterAdminInstitution();
//		AdminJobs.submitAdminActions();

		// Step 10-15
		
		LoadBrowser.openBrowser("chrome");
		// BrowserClass.openBrowser();
		//LoadBrowser.checkAccNum();
		BrowserClass.checkAccNum();
		//LoadBrowser.loadPrimeWebApplication();
		// BrowserClass.loadPrimeWebApplication();
		// CustomerServices.accountSearch();
		// FinancialAccountsDetail.checkNoStatementGen();
		// AccountStatementDetailsPage.verifyStatements();
		// System.out.println("Complete Flow Tested");
		
		Thread.sleep(10000);
		//FinancialAccountsDetail.aa();
		//BrowserClass.closeBrowser();
		LoadBrowser.closeBrowser();
	}

}
