//package com.dummy;
//
//import org.testng.annotations.Test;
//
//import com.entercard.framework.DatabaseConnection;
//import com.entercard.framework.LoadPropertyFile;
//import com.entercard.utilities.AdminJobs;
//import com.entercard.utilities.ConfigReader;
//import com.entercard.utilities.DBConnection;
//import com.entercard.utilities.ProcessQuery;
//
//@SuppressWarnings("unused")
//public class DbTest {
//
//	@Test
//	public static void testDatabase() throws Exception {
//
//		LoadPropertyFile lp = new LoadPropertyFile();
//		// System.out.println(LoadPropertyFile.properties.getProperty("databaseURL"));
//		// System.out.println(LoadPropertyFile.properties.getProperty("name"));
//		DatabaseConnection.setupDatabase(LoadPropertyFile.properties.getProperty("databaseURL"),
//				LoadPropertyFile.properties.getProperty("dbUserName"),
//				LoadPropertyFile.properties.getProperty("dbPassword")); // add
//																		// three
//																		// parameters
//																		// to
//																		// one
//																		// logic
//																		// and
//																		// execute
//																		// using
//																		// switch
//		DatabaseConnection.runQuery("SELECT * from CACCOUNTS WHERE stgeneral in ('CLSD','DCAC')AND ROWNUM <= 1");
//		DatabaseConnection.getAccountNumberQuery();	
//
//		DBConnection.closeDB();
//	}
//
//}
