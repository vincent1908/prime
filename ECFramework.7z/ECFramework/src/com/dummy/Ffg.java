package com.dummy;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class Ffg {

	@Test
	public void fff() throws Exception {

		// System.setProperty("webdriver.gecko.driver",
		// "C:\\Selenium\\repository\\ECFramework\\lib\\geckodriver.exe");
		//
		// driver = new FirefoxDriver();

		// DesiredCapabilities capabilities =
		// DesiredCapabilities.internetExplorer();
		//
		// capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING,
		// true);
		//
		// System.setProperty("webdriver.ie.driver","C:\\Selenium\\repository\\ECFramework\\lib\\IEDriverServer.exe");
		//
		// WebDriver driver= new InternetExplorerDriver(capabilities);
		System.setProperty("webdriver.ie.driver", "C:\\Selenium\\repository\\ECFramework\\lib\\IEDriverServer.exe");

		WebDriver driver = new InternetExplorerDriver();
		driver.manage().window().maximize();
		driver.get("http://ecwvp3web03t.ectest.local/PRMAD05T/prime/root/");
		Thread.sleep(5000);
		Runtime.getRuntime().exec("C:\\Selenium\\ThirdPartyTools\\first.exe");
		driver.quit();

	}

}
