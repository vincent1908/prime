package com.dummy;

import org.testng.annotations.Test;

import com.entercard.pages.AccountStatementDetailsPage;
import com.entercard.pages.CustomerServices;
//import org.//junit.Test;
import com.entercard.pages.FinancialAccountsDetail;
import com.entercard.utilities.AdminJobs;
import com.entercard.utilities.BrowserClass;
import com.entercard.utilities.ConfigReader;
import com.entercard.utilities.DBConnection;
import com.entercard.utilities.ProcessQuery;

@SuppressWarnings("unused")
public class NormCard_StatementGeneration {

	/*
	 * Atc002 - Verify the Statement generation for a NORM card.
	 */

	@Test
	public void verfiy_Stmt_Gen_for_NormCard() throws Exception {
		// Step 1-4

		DBConnection.setUpDB(); // Parametised
		DBConnection.runQuery(ConfigReader.prop.getProperty("SecondTestCaseB"));
		ProcessQuery.getAccountNumberQuery(); // Parametised
		DBConnection.closeDB();

		// // Step 5-10

		BrowserClass.openBrowser();
		BrowserClass.loadPrimeWebApplication();// parametrised
		CustomerServices.accountSearch();
	//	FinancialAccountsDetail.StatementNormCard();
		AccountStatementDetailsPage.cyclingTab();
		BrowserClass.closeBrowser();

		// 3779800011537998
		// Step 11-14

		// DB query

		// Step 15-19

		// 15 Click on Prime Job Administrator
		// 16 Login with valid username & password in Prime Job Adminstrator.
		// 17 Click on Jobs>>Scheduled & by Rt click select 'SUBMIT'
		// 18 Go to LOG >> click on current EOD
		// 19 Ensure completion of EOD

		// AdminJobs.loginPrJobAdmin();
		// AdminJobs.enterAdminUserId();
		// AdminJobs.enterAdminPassWord();
		// AdminJobs.enterAdminInstitution();
		// AdminJobs.submitAdminActions();

		// Step 21-26

		BrowserClass.openBrowser();
		BrowserClass.loadPrimeWebApplication();
		//FinancialAccountsDetail.StatementNormCard1();
		BrowserClass.closeBrowser();

		// Step 27-29

		// 27 Check the Location path according to the environment.
		// 28 Check for the details (Trxn date, Card number, merchant name, Trxn
		// Amount) of transactions posted.
		// 29 Compare the data details in both the file and webapplication

		// External File -- ToDO

	}

}
