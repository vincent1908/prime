package com.dummy;

public class ParamMethod {

	public static int add(int a, int b) {
		int c = a + b;
		return c;

	}

}
