package com.dummy;

import org.testng.annotations.Test;

import com.entercard.utilities.AdminJobs;

public class PrimeAdminTest {

	@Test
	public void testAdmin() throws Exception {
		AdminJobs.loginPrJobAdmin();
		AdminJobs.enterAdminUserId();
		AdminJobs.enterAdminPassWord();
		AdminJobs.enterAdminInstitution();
		AdminJobs.submitAdminActions();
	}
}
