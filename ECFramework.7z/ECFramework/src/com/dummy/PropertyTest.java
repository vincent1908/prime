/**
 * 
 */
package com.dummy;

import com.entercard.framework.LoadPropertyFile;
import com.entercard.utilities.ConfigReader;

public class PropertyTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//ConfigReader c = new ConfigReader();
		LoadPropertyFile l = new LoadPropertyFile();
	}

}
