package com.entercard.framework;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;

public class AdminJobs1 {

	static WiniumDriver driver;
	
	public AdminJobs1() {

		DesktopOptions options = new DesktopOptions();
		// options.setApplicationPath(ConfigReader.prop.getProperty("primeAdmin"));

		options.setApplicationPath(
				"prime-admin-path"); // called from property path in project

		try {
			// Runtime.getRuntime().exec(ConfigReader.runWinDriver());
			// driver = new WiniumDriver(new
			// URL(ConfigReader.prop.getProperty("winUrl")), options);
			driver = new WiniumDriver(new URL("http://localhost:9999"), options);
			// driver.findElement(By.name("Prime Jobs Administrator")).click();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	
}
