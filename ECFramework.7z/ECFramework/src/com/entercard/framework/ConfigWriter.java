package com.entercard.framework;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigWriter {
	
	/*Not Implemented as it overrides the entire property file*/

//	Properties properties;
//
//	public ConfigWriter() {
//
//		// TODO Auto-generated constructor stub
//		try {
//			Properties properties = new Properties();
//			properties.setProperty("AccountNumber", "5435600005826931");
//
//			File file = new File(
//					"C:\\Selenium\\repository\\ECFramework\\src\\com\\entercard\\base\\dataFile.properties");
//			FileOutputStream fileOut = new FileOutputStream(file);
//			properties.store(fileOut, "Account Number Processed");
//			System.out.println("------------------");
//			fileOut.close();
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
//
//	public String writeAccountNumber() {
//		properties.setProperty("AccountNumber", "5435600005826931");
//		return null;
//	}
	
	/*It should write specific value not file*/
	
	public static void main(String[] args) {
		try {
			Properties properties = new Properties();
			properties.setProperty("AccountNumber", "5435600005826931");

			File file = new File(
					"C:\\Selenium\\repository\\ECFramework\\src\\com\\entercard\\base\\dataFile.properties");
			FileOutputStream fileOut = new FileOutputStream(file);
			properties.store(fileOut, "Favorite Things");
			System.out.println("------------------");
			fileOut.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
