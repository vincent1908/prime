package com.entercard.framework;

/**
 * @author cgregami
 *
 */

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseConnection {

/*	Need to work for calling this file
*/	
	private static java.sql.Connection connection;
	private static java.sql.Statement statement;
	public static java.sql.ResultSet rs;
	static LoadPropertyFile prop;

	 public static void setupDatabase(String dbURL, String dbUN, String dbPW)
	 {
	 try {
	 Class.forName("oracle.jdbc.driver.OracleDriver");
	 connection = DriverManager.getConnection(dbURL, dbUN, dbPW);
	 } catch (Exception e) {
	 System.out.println(e.getMessage());
	 }
	 }

	// public static String executeQuery(String query, String columnValue) {
	//
	// try {
	// statement = connection.createStatement();
	// rs = statement.executeQuery(query);
	// while (rs.next()) {
	// accNum = rs.getString(columnValue);
	// // System.out.println(accNum);
	// }
	// } catch (SQLException e) {
	// System.out.println(e.getMessage());
	// }
	// return accNum;
	// }

	public static void setUpDB() {

		String databaseURL = "jdbc:Oracle:thin:@//10.251.130.88:1521/prmad05t";
		String user = "ec_swed";
		String password = "ec_swed";
		connection = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Connecting to Database...");
			connection = DriverManager.getConnection(databaseURL, user, password);
			if (connection != null) {
				System.out.println("Connected to the Database");
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		}
	}

	public static ResultSet runQuery(String query) {
		// public static ResultSet runQuery() {
		try {
			statement = connection.createStatement();
			rs = statement.executeQuery(query);
			System.out.println(rs);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rs;

	}

//	public static String getAccountNumberQuery() {
//		try {
//			while (rs.next()) {
//
//				accNum = rs.getString("NUMBERX");
//
//				System.out.println("Customer Acccount Number is : " + accNum);
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		return accNum;
//	}

	public static void closeDB() {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException ex) {
				System.out.println(ex.getMessage());
			}
		}
	}
	 public static void main(String[] args){
		 setUpDB();
		 runQuery("SELECT * from CACCOUNTS WHERE stgeneral in ('CLSD','DCAC')AND ROWNUM <= 1");
		 closeDB();
		 }
}
