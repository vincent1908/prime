package com.entercard.framework;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Dbc {
	public static java.sql.Connection connection;
	public static java.sql.Statement statement;
	public static java.sql.ResultSet rs;
	public static String accNum = null;

	public static void setUpDB() {

		String databaseURL = "jdbc:Oracle:thin:@//10.251.130.88:1521/prmad05t";
		String user = "ec_swed";
		String password = "ec_swed";
		connection = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Connecting to Database...");
			connection = DriverManager.getConnection(databaseURL, user, password);
			if (connection != null) {
				System.out.println("Connected to the Database");
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		}
	}

	public static ResultSet runQuery(String query) {
		// public static ResultSet runQuery() {
		try {
			statement = connection.createStatement();
			rs = statement.executeQuery(query);
			System.out.println(rs);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rs;

	}

	public static void closeDB() {
		if (connection != null) {
			try {
				connection.close();
				System.out.println("Database Connection Closed");
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	// public static void main(String[] args){
	// setUpDB();
	// runQuery("SELECT * from CACCOUNTS WHERE stgeneral in ('CLSD','DCAC')AND
	// ROWNUM <= 1");
	// closeDB();
	// }
}
