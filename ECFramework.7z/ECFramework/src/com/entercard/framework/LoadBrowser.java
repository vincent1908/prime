/**
 * 
 */
package com.entercard.framework;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.entercard.utilities.ConfigReader;

/**
 * @author cgregami
 *
 */
public class LoadBrowser extends DatabaseConnection { // it should not extends DB

	public static WebDriver driver;
	static ConfigReader configRead;

	public LoadBrowser(WebDriver driver) {
		driver = LoadBrowser.driver;
	}

//	public static void checkAccNum() {
//		System.out.println(accNum);
//	}

	public static void openBrowser(String browserType) {
		switch (browserType) {
		case "firefox":
			System.setProperty("webdriver.gecko.driver", "C:\\Selenium\\repository\\ECFramework\\lib\\geckodriver.exe");

			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			break;
		case "chrome":
			System.setProperty("webdriver.chrome.driver",
					"C:\\Selenium\\repository\\ECFramework\\lib\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			break;
		case "IE":
			System.setProperty("webdriver.ie.driver", "C:\\Selenium\\repository\\ECFramework\\lib\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			driver.manage().window().maximize();

			break;
		default:
			System.setProperty("webdriver.chrome.driver",
					"C:\\Selenium\\repository\\ECFramework\\lib\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
		}
	}

	public static void closeBrowser() throws InterruptedException {
		Thread.sleep(5000);
		driver.quit();
		// System.out.println("=====Browser Session End=====");

	}
	
	

	public static void loadPrimeWebApplication() throws Exception {
		configRead = new ConfigReader();
		Runtime.getRuntime().exec("C:\\Selenium\\ThirdPartyTools\\first.exe");
		driver.get(ConfigReader.prop.getProperty("AutoPrime"));
	}
}