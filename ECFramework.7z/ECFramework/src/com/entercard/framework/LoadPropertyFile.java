package com.entercard.framework;

import java.io.FileInputStream;
import java.util.Properties;

public class LoadPropertyFile {
	
	/*Need to work on loading multiple files*/

	public static Properties properties;

	public LoadPropertyFile() {
		try {
			properties = new Properties();

			properties.load(new FileInputStream(
					"C:\\Selenium\\repository\\ECFramework\\src\\com\\entercard\\properties\\dataFile.properties"));

			properties.load(new FileInputStream(
					"C:\\Selenium\\repository\\ECFramework\\src\\com\\entercard\\repository\\dataFile2.properties"));

			properties.putAll(properties);
			System.out.println("Property class loaded");

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
	
	public static void main (String [] args){
		
	}

}
