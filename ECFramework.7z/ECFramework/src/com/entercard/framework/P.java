package com.entercard.framework;

import java.sql.SQLException;

public class P extends Dbc {
	public static String accNum = null;
	// public class ProcessQuery extends DatabaseConnection {
	public static String getAccountNumberQuery() {
		
		try {
			while (rs.next()) {

				accNum = rs.getString("NUMBERX");

				System.out.println("Customer Acccount Number is : " + accNum);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return accNum;
	}

	// public static String Todo() {
	// try {
	// while (rs.next()) {
	//
	// accNum = rs.getString("NUMBERX");
	//
	// System.out.println("Customer Acccount Number is : " + accNum);
	// }
	// } catch (SQLException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	//
	// return accNum;
	// }

	
	public static void main (String [] args) {
		setUpDB();
		runQuery("SELECT * from CACCOUNTS WHERE stgeneral in ('CLSD','DCAC')AND ROWNUM <= 1");
		getAccountNumberQuery();
		closeDB();
		
	}
	}

