package com.entercard.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.entercard.utilities.ConfigReader;

@SuppressWarnings("unused")
public class AccountStatementDetailsPage extends FinancialAccountsDetail {

	public AccountStatementDetailsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	static String statementList;
	static By statementListBox = By.xpath(".//*[@id='StmtsList']");
	static By statementListBoxValeus = By.tagName("option");
	static By cyclingLink = By.xpath(".//*[@id='lblHeadingCycling']");
	static By NextDueDateField = By.xpath(".//*[@id='nextstmtdate']");
	static String EodDate =  "12/06/2017";
	static By viewButton = By.id("btnview");

	public static void verifyNoStatementGeneration() {

		WebElement table = driver.findElement(statementListBox);
		List<WebElement> rows = table.findElements(statementListBoxValeus);

		for (int i = 1; i < rows.size(); i++) {
			statementList = rows.get(i).getText();
			System.out.println(statementList);
		}
		if (statementList != null)
			System.out.println("Statement exist");
		else
			System.out.println("No Statement");
		
		new Select(driver.findElement(statementListBox)).selectByVisibleText("07/10/2016");
		driver.findElement(viewButton).click();

	}
	
	public static void verifyStatementExists() {

		WebElement table = driver.findElement(statementListBox);
		List<WebElement> rows = table.findElements(statementListBoxValeus);

		for (int i = 1; i < rows.size(); i++) {
			statementList = rows.get(i).getText();
			System.out.println(statementList);
		}
		if (statementList != null)
			System.out.println("Statement exist");
		else
			System.out.println("No Statement");

	}

	public static void cyclingTab() {
		
		driver.findElement(cyclingLink).click();
		// String StatementDate =
		// driver.findElement(NextDueDateField).getText();
		String StatementDate = driver.findElement(NextDueDateField).getAttribute("value");
		System.out.println(StatementDate);
		
//		if (StatementDate<EodDate){
//			System.out.println("No Statement Generated");
//		}else{
//	}
		
}
}
