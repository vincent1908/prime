package com.entercard.pages;

import org.openqa.selenium.WebDriver;

import com.entercard.utilities.BrowserClass;

public class AddressDetailsPage extends BrowserClass {

	public AddressDetailsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

}
