package com.entercard.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.entercard.utilities.BrowserClass;

public class ApplicationManager extends BrowserClass {

	public ApplicationManager(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public static void am() {
		System.out.println("launching chrome browser");
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\repository\\ECFramework\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(
				"http://cgregami:Entercard17@ecwvp3web03t.ectest.local/PRMAD06T/prime/WebApplications/ApplicationManager/Default.aspx");
		driver.switchTo().frame(0);
		new Select(driver.findElement(By.id("leftPage_leftMenu_ddlApplicOutline"))).selectByVisibleText("Card");
		driver.findElement(By.id("leftPage_leftMenu_btnCreateNew")).click();
		driver.switchTo().frame(1);
		new Select(driver.findElement(By.id("customerDetails_customerDetails_ddlCustomerTemplate")))
				.selectByVisibleText("Customer Template");
		driver.findElement(By.cssSelector("option[value=\"4\"]")).click();
	}

}
