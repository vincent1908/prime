package com.entercard.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.entercard.utilities.BrowserClass;

public class CardPage extends BrowserClass {

	public CardPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	static By cardLink = By.xpath(".//*[@id='MainPageCardxUC_lblCardHeader']");
	static By takeActionButton = By.xpath(".//*[@id='PrimeMenuCtrl_TakeActionbtn']");
	static By replaceCardButton = By.xpath(".//*[@id='PrimeMenuCtrl_ActionTree']/table/tbody/tr[16]/td/a/font");
	static By okButton = By.xpath(".//*[@id='PrimeMenuCtrl_ActionTree']/table/tbody/tr[16]/td/a/font");
	static By cancelButton = By.xpath(".//*[@id='CancelButton']");

	public static void cardEmbossing() throws Exception {
		driver.switchTo().frame(1);
		driver.findElement(cardLink).click();
		driver.findElement(takeActionButton).click();
		driver.findElement(replaceCardButton).click();
		Thread.sleep(3000);
		// Boolean OkBttn = driver.findElement(okButton).isDisplayed();
		// System.out.println(OkBttn);
		// Boolean CanBttn = driver.findElement(cancelButton).isDisplayed();
		// System.out.println(CanBttn);
		// Assert.assertEquals(driver.findElement(By.id("btnOk")).getText(),
		// "");
		// Assert.assertEquals(driver.findElement(By.id("CancelButton")).getText(),
		// "");
		driver.findElement(cancelButton).click();

	}
}
