package com.entercard.pages;

import org.openqa.selenium.WebDriver;

import com.entercard.utilities.BrowserClass;

public class CorporateCustomersPage extends BrowserClass{

	public CorporateCustomersPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	
	

}
