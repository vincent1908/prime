package com.entercard.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.entercard.utilities.BrowserClass;

public class CustomerServices extends BrowserClass {

	public CustomerServices(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	static By cardRadioButton = By.xpath(".//*[@id='optNumber_0']");
	static By accountRadioButton = By.xpath(".//*[@id='optNumber_1']");
	By peopleRadioButton = By.xpath(".//*[@id='optNumber_2']");
	static By autoRadioButton = By.xpath(".//*[@id='optNumber_3']");
	static By accountNumberTextBox = By.xpath(".//*[@id='AccNumberTextBox']");
	static By findButton = By.xpath(".//*[@id='btnFind']");
	By linkSecurity = By.xpath(".//*[@id='Repeater1__ctl10_hypLinks']");

	public static void accountSearch() throws Exception {

		driver.switchTo().frame(0);
		driver.findElement(accountRadioButton).click();
		driver.findElement(accountNumberTextBox).sendKeys(accNum);
		driver.findElement(findButton).click();
		Thread.sleep(3000);
		System.out.println("Account Search Sucess");

	}
	public static void accountSearchClosed() throws Exception {

		driver.switchTo().frame(0);
		driver.findElement(accountRadioButton).click();
		driver.findElement(accountNumberTextBox).sendKeys(accNum);
		driver.findElement(findButton).click();
		Thread.sleep(3000);
		System.out.println("Account Search Sucess");

	}
	
	public static void accountSearchNorm() throws Exception {

		driver.switchTo().frame(0);
		driver.findElement(accountRadioButton).click();
		driver.findElement(accountNumberTextBox).sendKeys(accNum);
		driver.findElement(findButton).click();
		Thread.sleep(3000);
		System.out.println("Account Search Sucess");

	}

	public static void accountSearchEmbossing() throws Exception {

		driver.switchTo().frame(0);
		driver.findElement(accountRadioButton).click();
		driver.findElement(accountNumberTextBox).sendKeys("4581990000004287");
		driver.findElement(findButton).click();
		Thread.sleep(3000);
		System.out.println("Account Search Sucess");

	}
	
	public static void accountSearchVisaCtf() throws Exception
	{
		driver.switchTo().frame(0);
		driver.findElement(accountRadioButton).click();
		driver.findElement(accountNumberTextBox).sendKeys("4581990000005229");
		driver.findElement(findButton).click();
		Thread.sleep(3000);
		System.out.println("Account Search Sucess");
	}
	public static void cardSearch() throws Exception {

		driver.switchTo().frame(0);
		driver.findElement(cardRadioButton).click();
		// ToDo Card Number
		// driver.findElement(accountNumberTextBox).sendKeys(accNum);
		driver.findElement(findButton).click();
		System.out.println("Card Search Sucess");

	}

	public static void peopleSearch() throws Exception {

	}

	public static void autoSearch() throws Exception {
		
		driver.switchTo().frame(0);
		driver.findElement(autoRadioButton).click();
		driver.findElement(accountNumberTextBox).sendKeys("4581990000004287");
		driver.findElement(findButton).click();
		Thread.sleep(3000);
		System.out.println("Auto search success");
	}

}
