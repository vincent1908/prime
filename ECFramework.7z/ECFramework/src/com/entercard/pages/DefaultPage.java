package com.entercard.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.entercard.utilities.BrowserClass;

public class DefaultPage extends BrowserClass {

	public DefaultPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	WebDriver driver;
	By linkApplicationManager = By.xpath(".//*[@id='Repeater1__ctl2_hypLinks']");
	By linkCustomerServices = By.xpath(".//*[@id='Repeater1__ctl3_hypLinks']");
	By linkManualTransactions = By.xpath(".//*[@id='Repeater1__ctl4_hypLinks']");
	By linkTransactionManagement = By.xpath(".//*[@id='Repeater1__ctl5_hypLinks']");
	By linkCorporateCustomers = By.xpath(".//*[@id='Repeater1__ctl6_hypLinks']");
	By linkSecurity = By.xpath(".//*[@id='Repeater1__ctl10_hypLinks']");

	// click Application Manager link
	public void clickApplicationManager() {
		driver.findElement(linkApplicationManager).click();
	}

}
