package com.entercard.pages;

import org.testng.Assert;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.entercard.utilities.BrowserClass;
import com.entercard.utilities.ConfigReader;

@SuppressWarnings("unused")
public class FinancialAccountsDetail extends BrowserClass {

	public FinancialAccountsDetail(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	static By accountPageTitle = By.xpath(".//*[@id='MainPageAccUC_lblAccountHeader']");
	static By generalStatusField = By.xpath(".//*[@id='MainPageAccUC_AccStatusGen']");
	static By statementMagnifyingGlass = By.xpath(".//*[@id='MainPageAccUC_AccStatementuc_lblStatementImage']/img");
	static By last5TransactionMagnifyingGlass = By.xpath(".//*[@id='MainPageAccUC_lblTransactionsHeaderImage']/img");

	public static void navigateAccountStatementDetailsPage() throws Exception {
		driver.switchTo().frame(1);
		String accountStatus = driver.findElement(generalStatusField).getText();
		System.out.println(accountStatus);
		driver.findElement(statementMagnifyingGlass).click();
	}

	public static void navigateTransactionPage() {
		driver.switchTo().frame(1);
		driver.findElement(last5TransactionMagnifyingGlass).click();
	}

	public static void Rem1ToRem2() {
		driver.switchTo().frame(0);
		driver.findElement(By.id("optNumber_1")).click();
		driver.findElement(By.id("AccNumberTextBox")).click();
		driver.findElement(By.id("AccNumberTextBox")).clear();
		driver.findElement(By.id("AccNumberTextBox")).sendKeys("3779800011538153");
		driver.findElement(By.id("btnFind")).click();
		driver.switchTo().frame(1);
		String initialStatus = driver.findElement(By.id("MainPageAccUC_AccStatusGen")).getText();
		System.out.println(initialStatus);
		driver.findElement(By.cssSelector("img[title=\"Statements\"]")).click();
		driver.findElement(By.id("lblHeadingCycling")).click();
		String realDueDate = driver.findElement(By.id("nextstmtdate")).getText();
	}
	
	public static void aa() {
		driver.findElement(By.xpath(".//*[@id='btnTrxns']")).click();
	}

	public static void atc015() throws Exception {

		driver.switchTo().frame("CardLeftPage");
		// driver.switchTo().frame(0);
		Thread.sleep(5000);
		WebElement e1 = driver.findElement(By.xpath("//*[@id='AdvSearch']"));
		System.out.println(e1.getText());
		e1.click();
		Thread.sleep(5000);

		driver.switchTo().defaultContent();
		// frame("CardMainPage");
		WebElement e12 = driver.findElement(By.name("CardMainPage"));
		driver.switchTo().frame(e12);

		WebElement e = driver.findElement(By.id("lblentity"));
		System.out.println(e.getText());

		// driver.switchTo().frame("CardLeftPage");

		// driver.switchTo().parentFrame();
		// driver.switchTo().frame("AdvSearchForm");
		// driver.switchTo().window("CardMainPage");
		// driver.switchTo().frame(1);

		new Select(driver.findElement(By.id("dropSearchBy"))).selectByVisibleText("Accounts");
		new Select(driver.findElement(By.id("dropFields"))).selectByVisibleText("All Fields");
		new Select(driver.findElement(By.id("FieldsList"))).selectByVisibleText("MINPAYCOMBINATION");
		driver.findElement(By.cssSelector("option[value=\"MINPAYCOMBINATION\"]")).click();
		new Select(driver.findElement(By.id("FieldsList"))).selectByVisibleText("STMTBASEDATEIND");
		new Select(driver.findElement(By.id("FieldsList"))).selectByVisibleText("STGENERAL");
		driver.findElement(By.id("BrowseButtonEllipse_txtValues")).clear();
		driver.findElement(By.id("BrowseButtonEllipse_txtValues")).sendKeys("NORM");
		WebElement e2 = driver.findElement(By.id("Findbtn"));
		e2.click();
		driver.findElement(By.xpath(".//*[@id='caccounts1153836']/td[1]/a")).click();
		Thread.sleep(3000);
		driver.switchTo().frame(1);
		driver.findElement(By.id("MainPageAccUC_lblAccountHeader")).click();
		driver.findElement(By.id("PrimeMenuCtrl_TakeActionbtn")).click();
		WebElement e3 = driver
				.findElement(By.xpath(".//*[@id='PrimeMenuCtrl_ActionTree']/table/tbody/tr[15]/td/a[2]/font"));
		e3.click();
		driver.findElement(By.id("PrimeMenuCtrl_TakeActionbtn")).click();
		driver.findElement(By.xpath("//div[@id='PrimeMenuCtrl_ActionTree']/table/tbody/tr[17]/td/a/font")).click();
		new Select(driver.findElement(By.id("ServiceArgument_ArgDropDown"))).selectByVisibleText("CLSB");
		driver.findElement(By.id("btnYes")).click();

	}

	// public static void StatementNormCard1() throws Exception {
	//
	// driver.switchTo().frame(0);
	// driver.findElement(By.xpath(".//*[@id='optNumber_1']")).click();
	// driver.findElement(By.xpath(".//*[@id='AccNumberTextBox']")).sendKeys("4581990000005229");
	// driver.findElement(By.xpath(".//*[@id='btnFind']")).click();
	// Thread.sleep(5000);
	// driver.switchTo().frame(1);
	// driver.findElement(By.xpath(".//*[@id='MainPageAccUC_AccStatementuc_lblStatementImage']/img")).click();
	//
	// String AccPgTile =
	// driver.findElement(By.id("HeaderTable_lblentity")).getText();
	//
	// Assert.assertEquals("Account Statement Details", AccPgTile);
	// System.out.println(AccPgTile);
	//
	// driver.findElement(By.id("lblHeadingCycling")).click();
	// String date = driver.findElement(By.id("nextstmtdate")).getText();
	// new
	// Select(driver.findElement(By.id("StmtsList"))).selectByVisibleText("07/10/2016");
	// driver.findElement(By.id("btnview")).click();
	//
	// }

	public static void checkDispTrancFlow() {
		driver.switchTo().frame(0);
		driver.findElement(By.id("optNumber_0")).click();
		driver.findElement(By.id("NumberTextBox")).click();
		driver.findElement(By.id("NumberTextBox")).clear();
		driver.findElement(By.id("NumberTextBox")).sendKeys("4581990000000797");
		driver.findElement(By.id("btnFind")).click();
		driver.switchTo().frame(1);
		driver.findElement(By.cssSelector("img[title=\"Last 5 Transactions\"]")).click();
		new Select(driver.findElement(By.id("MonthsBackList"))).selectByVisibleText("20 Months");
		driver.findElement(By.cssSelector("option[value=\"20\"]")).click();
		driver.findElement(By.xpath("(//a[contains(text(),'View')])[7]")).click();
		new Select(driver.findElement(By.id("cboAction"))).selectByVisibleText("Dispute Transaction");
		driver.findElement(By.id("btnAction")).click();
		driver.findElement(By.id("btnOk")).click();
		driver.findElement(By.id("btnBack")).click();
		driver.findElement(By.id("btnBack")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//table[@id='TrxnGrid']/tbody/tr[9]/td/img")).getText(), "");
	}

	public static void Rem1ToNorm() throws Exception {

		// driver.switchTo().frame(0);
		// driver.findElement(By.id("AdvSearch")).click();
		// Thread.sleep(3000);
		// driver.switchTo().parentFrame();
		// Thread.sleep(3000);
		// new
		// Select(driver.findElement(By.id("dropSearchBy"))).selectByVisibleText("Accounts");
		// new
		// Select(driver.findElement(By.id("dropFields"))).selectByVisibleText("All
		// Fields");
		// new
		// Select(driver.findElement(By.id("FieldsList"))).selectByVisibleText("STGENERAL");
		// driver.findElement(By.cssSelector("option[value=\"STGENERAL\"]")).click();
		// driver.findElement(By.id("BrowseButtonEllipse_txtValues")).clear();
		// driver.findElement(By.id("BrowseButtonEllipse_txtValues")).sendKeys("REM1");
		// driver.findElement(By.id("Findbtn")).click();
		// String accNo =
		// driver.findElement(By.linkText("3779800011538153")).getText();
		driver.switchTo().frame(0);
		driver.findElement(By.id("optNumber_1")).click();
		driver.findElement(By.id("AccNumberTextBox")).click();
		driver.findElement(By.id("AccNumberTextBox")).clear();
		driver.findElement(By.id("AccNumberTextBox")).sendKeys("4581990000005229");
		driver.findElement(By.id("btnFind")).click();
		driver.switchTo().frame(1);
		String accountStatus = driver.findElement(generalStatusField).getText();
		System.out.println(accountStatus);
		driver.findElement(statementMagnifyingGlass).click();
		new Select(driver.findElement(By.id("StmtsList"))).selectByVisibleText("03/02/2017");
		String dbt = driver.findElement(By.id("Debits")).getAttribute("value");
		System.out.println(dbt);

		driver.navigate().to(
				"http://cshamalk:Entercard@17@ecwvp3web03t.ectest.local/PRMAD06T/prime/WebApplications/ManualTransactions/Default.aspx");
		driver.switchTo().frame(1);
		driver.findElement(By.id("tabMenu2")).click();

		driver.findElement(By.id("btnBatchNew")).click();

	}

	

	public static void Rem2ToRem3() {
		driver.switchTo().frame(0);
		driver.findElement(By.id("optNumber_1")).click();
		driver.findElement(By.id("AccNumberTextBox")).click();
		driver.findElement(By.id("AccNumberTextBox")).clear();
		driver.findElement(By.id("AccNumberTextBox")).sendKeys("3779800011544818");
		driver.findElement(By.id("btnFind")).click();
		driver.switchTo().frame(1);
		String initialStatus = driver.findElement(By.id("MainPageAccUC_AccStatusGen")).getText();
		System.out.println(initialStatus);
		driver.findElement(By.cssSelector("img[title=\"Statements\"]")).click();
		driver.findElement(By.id("lblHeadingCycling")).click();
		String realDueDate = driver.findElement(By.id("nextstmtdate")).getText();
	}

	public static void NormToRem1a() {
		driver.switchTo().frame(0);
		driver.findElement(By.id("optNumber_1")).click();
		driver.findElement(By.id("AccNumberTextBox")).click();
		driver.findElement(By.id("AccNumberTextBox")).clear();
		driver.findElement(By.id("AccNumberTextBox")).sendKeys("3779800011538153");
		driver.findElement(By.id("btnFind")).click();
		driver.switchTo().frame(1);
		String finalStatus = driver.findElement(By.id("MainPageAccUC_AccStatusGen")).getText();
		System.out.println(finalStatus);
	}

	public static void Rem1ToRem2a() {
		driver.switchTo().frame(0);
		driver.findElement(By.id("optNumber_1")).click();
		driver.findElement(By.id("AccNumberTextBox")).click();
		driver.findElement(By.id("AccNumberTextBox")).clear();
		driver.findElement(By.id("AccNumberTextBox")).sendKeys("3779800011544818");
		driver.findElement(By.id("btnFind")).click();
		driver.switchTo().frame(1);
		String finalStatus = driver.findElement(By.id("MainPageAccUC_AccStatusGen")).getText();
		System.out.println(finalStatus);
	}

	public static void Rem2ToRem3a() {
		driver.switchTo().frame(0);
		driver.findElement(By.id("optNumber_1")).click();
		driver.findElement(By.id("AccNumberTextBox")).sendKeys("3779800011537998");
		driver.findElement(By.id("btnFind")).click();
		driver.switchTo().frame(1);
		String finalStatus = driver.findElement(By.id("MainPageAccUC_AccStatusGen")).getText();
		System.out.println(finalStatus);
	}

	public static void ctffile() {
		driver.switchTo().frame(0);
		driver.findElement(By.id("optNumber_1")).click();
		driver.findElement(By.id("AccNumberTextBox")).click();
		driver.findElement(By.id("AccNumberTextBox")).clear();
		driver.findElement(By.id("AccNumberTextBox")).sendKeys("4581990000005229");
		driver.findElement(By.id("btnFind")).click();
		driver.switchTo().frame(1);
		driver.findElement(By.cssSelector("img[title=\"Last 5 Transactions\"]")).click();
		driver.findElement(By.xpath("//table[@id='TrxnGrid']/tbody/tr[2]/td[3]")).getText();

	}

}