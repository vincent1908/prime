package com.entercard.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.entercard.utilities.BrowserClass;

public class ManualTransactionsPage extends BrowserClass{
	
	/*Tests are breaking while executing this page*/

	public ManualTransactionsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	static By paymentsAndAdjustmentTab = By.id("tabMenu2");
	
	public static void batchProcess(){
		
		//driver.switchTo().frame(1);
		
//		List<WebElement> el = driver.findElements(By.xpath("//*"));
//        int count=0;
//        for ( WebElement e : el ) {
//         System.out.println( e.getTagName()+"    "+e.getText());
//
//         count++;
//
//        }
//      System.out.println(count );
		
		driver.findElement(paymentsAndAdjustmentTab).click();
		
	}

}
