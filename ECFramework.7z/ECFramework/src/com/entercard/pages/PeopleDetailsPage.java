package com.entercard.pages;

import org.openqa.selenium.WebDriver;

import com.entercard.utilities.BrowserClass;

public class PeopleDetailsPage extends BrowserClass{

	public PeopleDetailsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

}
