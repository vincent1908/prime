package com.entercard.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.entercard.utilities.BrowserClass;

public class TransactionPage extends BrowserClass {

	public TransactionPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	static By transactionPageHeader = By.xpath(".//*[@id='HeaderTable_lblentity']");
	static By tableValue1 = By.xpath(".//*[@id='TrxnGrid']/tbody/tr[2]/td[4]");

	public static void postedTransaction() throws Exception {
		System.out.println(driver.findElement(transactionPageHeader).getText());
		//WebElement baseTable = driver.findElement(By.tagName("table"));
		String l1 = driver.findElement(tableValue1).getText();
		System.out.println(l1); // compare this with value posted from Ctf file

	}

}
