package com.entercard.scripts;

import org.testng.annotations.Test;

import com.entercard.framework.DatabaseConnection;
import com.entercard.framework.LoadPropertyFile;
import com.entercard.pages.AccountStatementDetailsPage;
import com.entercard.pages.CustomerServices;
import com.entercard.pages.FinancialAccountsDetail;
import com.entercard.utilities.AdminJobs;
import com.entercard.utilities.BrowserClass;
import com.entercard.utilities.ConfigReader;
import com.entercard.utilities.DBConnection;
import com.entercard.utilities.ProcessQuery;

@SuppressWarnings("unused")
public class ATC001_Closed_NoStatementGeneration {

	/*
	 * ATC001 Verify that the statement is not generated for Close / DCAC
	 * accounts.
	 */

	@Test
	public void closedAccounts() throws Exception {

		// Step 1-4

		DBConnection.setUpDB(); // Parametised
		// DBConnection.setupDatabase("jdbc:Oracle:thin:@//10.251.130.88:1521/prmad05t","ec_swed","ec_swed");
		DBConnection.runQuery(ConfigReader.prop.getProperty("FirstTestCase"));
		// DBConnection.runQuery(LoadPropertyFile.properties.getProperty("FirstTestCase"));
		ProcessQuery.getAccountNumberQuery(); // Parametised
		// ProcessQuery.getAccountNumberQuerya("NUMBERX");
		DBConnection.closeDB();

		// LoadPropertyFile lp = new LoadPropertyFile();
		// DatabaseConnection.setupDatabase(LoadPropertyFile.properties.getProperty("databaseURL"),
		// LoadPropertyFile.properties.getProperty("dbUserName"),
		// LoadPropertyFile.properties.getProperty("dbPassword"));
		// DatabaseConnection.executeQuery(LoadPropertyFile.properties.getProperty("FirstTestCase"),
		// LoadPropertyFile.properties.getProperty("accountNumber"));
		// System.out.println(DatabaseConnection.executeQuery(LoadPropertyFile.properties.getProperty("FirstTestCase"),
		// LoadPropertyFile.properties.getProperty("accountNumber")));
		// DBConnection.closeDB();

		// Step 5-9

		// AdminJobs.loginPrJobAdmin();
		// AdminJobs.enterAdminUserId();
		// AdminJobs.enterAdminPassWord();
		// AdminJobs.enterAdminInstitution();
		// AdminJobs.submitAdminActions();

		// Step 10-15

		// BrowserClass.openBrowser();
		BrowserClass.openBrowser("chrome");
		BrowserClass.loadPrimeWebApplication();
		CustomerServices.accountSearch();
		FinancialAccountsDetail.navigateAccountStatementDetailsPage();
		AccountStatementDetailsPage.verifyNoStatementGeneration();
		BrowserClass.closeBrowser();
	}

}
