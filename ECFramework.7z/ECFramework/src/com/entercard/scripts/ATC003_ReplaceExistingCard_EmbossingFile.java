package com.entercard.scripts;

import org.testng.annotations.Test;

import com.entercard.pages.CardPage;
import com.entercard.pages.CustomerServices;
import com.entercard.pages.FinancialAccountsDetail;
import com.entercard.utilities.AdminJobs;
import com.entercard.utilities.BrowserClass;

@SuppressWarnings("unused")
public class ATC003_ReplaceExistingCard_EmbossingFile {

	/*
	 * Verify the embossing file when an existing card is Replace�and verify the
	 * layout of the embossing file(I.e. Non-Amex product)
	 */

	@Test
	public void verfiy_Embossing_Replcae() throws Exception {

		// Step 1-5

		BrowserClass.openBrowser();
		BrowserClass.loadPrimeWebApplication();
		CustomerServices.accountSearchEmbossing();
		CardPage.cardEmbossing();
		BrowserClass.closeBrowser();

		// Step 6-9

		// AdminJobs.loginPrJobAdmin();
		// AdminJobs.enterAdminUserId();
		// AdminJobs.enterAdminPassWord();
		// AdminJobs.enterAdminInstitution();
		// AdminJobs.submitAdminActions();

		// Step 10-36

		// Embossing File
	}
}
