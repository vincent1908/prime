package com.entercard.scripts;

import org.testng.annotations.Test;

import com.entercard.pages.CustomerServices;
import com.entercard.pages.FinancialAccountsDetail;
import com.entercard.pages.TransactionPage;
import com.entercard.utilities.BrowserClass;

public class ATC004_Visa_CtfFileVerfification {

	/*
	 * ATC004 Verify the posting of (Sales) transaction through visa_CTF file to
	 * a card and verifying it in Customer Services /Transaction Management�
	 */
	@Test
	public void verifyVisaCtfFile() throws Exception {

		// Step 1-2

		// Visa Ctf file

		// Step 3-11

		// Prime Job Admin
		// Needs seperate job to run (Adhoc job)

		// Step 12-26

		BrowserClass.openBrowser();
		BrowserClass.loadPrimeWebApplication();
//		FinancialAccountsDetail.ctffile();
		CustomerServices.accountSearchVisaCtf();
		FinancialAccountsDetail.navigateTransactionPage();
		TransactionPage.postedTransaction();
		BrowserClass.closeBrowser();
		
		

	}

}
