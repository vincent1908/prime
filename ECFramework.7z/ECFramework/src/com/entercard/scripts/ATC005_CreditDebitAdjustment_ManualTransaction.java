package com.entercard.scripts;

import org.testng.annotations.Test;

import com.entercard.pages.ManualTransactionsPage;
import com.entercard.utilities.BrowserClass;
import com.entercard.utilities.ConfigReader;
import com.entercard.utilities.DBConnection;
import com.entercard.utilities.ProcessQuery;

public class ATC005_CreditDebitAdjustment_ManualTransaction {

	/*
	 * ATC005 Verify the posting of CR/ DB adjustments transaction through
	 * manual transaction to a card and verify it in Customer Services
	 * /Transaction Management�
	 */

	@Test
	public void CreditDebitTransaction() throws Exception {

		// Step 1-4

		DBConnection.setUpDB(); // Parametised
		DBConnection.runQuery(ConfigReader.prop.getProperty("SecondTestCaseB"));
		ProcessQuery.getAccountNumberQuery(); // Parametised
		DBConnection.closeDB();

		// Step 5-30

		BrowserClass.openBrowser();
		BrowserClass.loadPrimeWebApplication1(ConfigReader.prop.getProperty("PrimeManaualTransaction5"));
		//ManualTransactionsPage.batchProcess();
		BrowserClass.closeBrowser();
		/* Unable to Script due to environment issues */

		// BrowserClass.closeBrowser();

	}

}
