package com.entercard.scripts;

import org.testng.annotations.Test;

import com.entercard.pages.AccountStatementDetailsPage;
import com.entercard.pages.CustomerServices;
import com.entercard.pages.FinancialAccountsDetail;
import com.entercard.utilities.AdminJobs;
import com.entercard.utilities.BrowserClass;
import com.entercard.utilities.ConfigReader;
import com.entercard.utilities.DBConnection;
import com.entercard.utilities.ProcessQuery;

@SuppressWarnings("unused")
public class ATC006_AccountNormToREM1 {

	/*
	 * ATC006 "Verify that the Account is escalated to next level (i.e. NORM -->
	 * REM1) when a real due date EOD is process and account have over due
	 * amount. "
	 */

	@Test
	public void NormToRem1() throws Exception {

		// Step 1-4

		DBConnection.setUpDB(); // Parametised
		DBConnection.runQuery(ConfigReader.prop.getProperty("SecondTestCaseB"));
		ProcessQuery.getAccountNumberQuery(); // Parametised
		DBConnection.closeDB();

		// Step Step 5-8

		// EOD

		/* Step 9-15 */

		BrowserClass.openBrowser();
		BrowserClass.loadPrimeWebApplication();
		CustomerServices.accountSearch();
		FinancialAccountsDetail.navigateAccountStatementDetailsPage();
		AccountStatementDetailsPage.cyclingTab();
		BrowserClass.closeBrowser();

		// Step 16- 19

		// DBConnection.setUpDB(); // Parametised
		// DBConnection.runQuery(ConfigReader.prop.getProperty("ChangeEodDate"));
		// DBConnection.closeDB();

		// Step 20 -23

		// Prime Job admin

		// Step 24 -28

		BrowserClass.openBrowser();
		BrowserClass.loadPrimeWebApplication();
		CustomerServices.accountSearch();
		FinancialAccountsDetail.navigateAccountStatementDetailsPage();
		BrowserClass.closeBrowser();

	}
}
