package com.entercard.scripts;

import org.testng.annotations.Test;

import com.entercard.pages.AccountStatementDetailsPage;
import com.entercard.pages.CustomerServices;
import com.entercard.pages.FinancialAccountsDetail;
import com.entercard.utilities.BrowserClass;
import com.entercard.utilities.ConfigReader;
import com.entercard.utilities.DBConnection;
import com.entercard.utilities.ProcessQuery;

public class ATC007_AccountRem1ToRem2 {

	@Test
	public static void Rem1ToRem2() throws Exception {

		// 1 - 4

		DBConnection.setUpDB(); // Parametised
		DBConnection.runQuery(ConfigReader.prop.getProperty("Rem1"));
		ProcessQuery.getAccountNumberQuery(); // Parametised
		DBConnection.closeDB();

		// 5 - 8

		// admin job

		// 9 - 15

		BrowserClass.openBrowser();
		BrowserClass.loadPrimeWebApplication();
		CustomerServices.accountSearch();
		FinancialAccountsDetail.navigateAccountStatementDetailsPage();
		AccountStatementDetailsPage.cyclingTab();
		BrowserClass.closeBrowser();

		// 16 -19

		// db job

		// 20 - 23

		// admin job

		// 24 -28

		BrowserClass.openBrowser();
		BrowserClass.loadPrimeWebApplication();
		CustomerServices.accountSearch();
		FinancialAccountsDetail.navigateAccountStatementDetailsPage();
		AccountStatementDetailsPage.cyclingTab();
		BrowserClass.closeBrowser();

	}

}
