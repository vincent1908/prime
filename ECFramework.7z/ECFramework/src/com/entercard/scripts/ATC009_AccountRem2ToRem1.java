package com.entercard.scripts;

import org.testng.annotations.Test;

public class ATC009_AccountRem2ToRem1 {

	@Test
	public static void R2R() {
		// 1 Click on PLSQL Developer
		// 2 Login with valid username & password by clicking under FILE
		// >>NEW>>DATABASE CONNECTION
		// 3 "Run the given query in right pannel of the screen :- select * from
		// caccounts where stgeneral in ('REM1');
		// Note the account number."

		// db

		//
		// 4 Open new internet explorer page and put the
		// 'http://ecwvp3web02t.ectest.local/Prmsad04t/Root/Default.aspx' in
		// address bar.
		// 5 Login with valid username & password in Prime Issuer Web
		// Application
		// 6 "Window get opened with below options :-
		// Application Manager
		// Customer Services
		// Manual Transactions
		// Transaction Management
		// Corporate Customer
		// Security
		//
		// "
		// 7 Select the radio button 'Account' Enter the above noted account
		// number in left side of the textbox & Click on Find button
		// 8 Go to Financial Account level----->> Last statement ----->> and
		// click on magnifying glass icon i. e. statements
		// 9 Click on the second last statement and fetch the value from debits
		// field.
		// 10 "Open the Manual Transactions application
		//
		//
		// "
		// 11 Click on Payments & Adjustments
		// 12 Click on New Batch
		// 13 Fill up all required details & click on 'Save' button
		// 14 Select the created batch & click on Transactions
		// 15 Click on New Button & select the radio button 'Account', put the
		// account number in text box & click on Get Data
		// 16 Select the Type 'Payment' from dropdown list, put the amount that
		// was picked from the 2nd last statement earlier & click on 'SAVE'
		// 17 click on 'BACK' button & click on Close Batch
		// 18 Click 'YES' on warning message

		// web

		//
		// 19 Login with valid username & paswword in Prime 3
		// (ecwvp3ts01t.ectest.local) Server.
		// 20 Check for Prime Job Admin.exe--------->Double click on exe
		// 21 Navigate the Job admin application and find the Schedule Job at
		// the left corner of the screen.
		// 22 Right click on schedule Job--->>
		// 23 Click on Yes button.
		// 24 Go to--->> Running jobs left down corner.
		// 25 Click on Schedule job that you have submitted.
		// 26 Wait for finishing the Job.

		// admin

		// 27 "Login with valid username & paswword in Prime
		// 3(ecwvp3web02t.ectest.local
		// ) Server."
		// 28 Navigate the open page.
		// 29 "
		// Click on 'Customer Services'
		// "
		// 30 Select the radio button 'Account' enter the above noted account
		// numberin left side of the textbox & Click on Find button
		// 31 Check the account status in Financial Account Details screen.
		//

		// web
	}

}
