package com.entercard.scripts;

import org.testng.annotations.Test;

public class ATC010_AccountRem3ToRem2 {

	@Test
	public static void R2R() {
		
		
//		1	Click on PLSQL Developer
//		2	Login with valid username & password by clicking under FILE >>NEW>>DATABASE CONNECTION
//		3	Run the given query in right pannel of the screen :- select * from caccounts where stgeneral in ('REM2');
//		4	Notedown any Accounts having stgeneral status as NORM
		
		// db job
		
		// 5 Login with valid username & password in Prime Job Adminstrator.
		// 6 Click on Jobs>>Scheduled & by Rt click select 'SUBMIT'
		// 7 Go to LOG >> click on current EOD
		// 8 Ensure completion of EOD on statement date
		
		// admin job
		
		
//		9	Open new internet explorer page and Enter the 'http://ecwvp3web02t.ectest.local/Prmsad04t/Root/Default.aspx' in address bar.
//		10	Login with valid username & password in Prime Issuer Web Application
//		11	"Window get opened with below options :-
//		Application Manager
//		Customer Services
//		Manual Transactions
//		Transaction Management
//		Corporate Customer
//		Security
//		Click on 'Customer Services'
//		"
//		12	Select the radio button 'Account' Enter the account number (Which is noted earlier) in left side of the textbox &  Click on Find button
//		13	Go to Financial Account level----->>  Last statement ----->> and click on magnifying glass icon i. e. statements
//		14	Click on 'Cycling' Tab & note down the 'Real Due Date'
//		15	Login with valid username & paswword in Prime 3 (ecwvp3ts01t.ectest.local) Server.
		
		
		// Prime Web
		
//		16	Check for PLSQL Developer--------->>Double click on PLSQL Developer.
//		17	Login with valid username & password by clicking under FILE >>NEW>>DATABASE CONNECTION
//		18	Run the below given query in right pannel of the screen :- select max(serno) from eods; take the serno and Enter in select * from eods where serno = (outEnter from 1st query)
//		19	Change the current eod with new statement date.
		
		
		
		// db job
		
		
		
//		20	Login with valid username & password in Prime Job Adminstrator.
//		21	Run an EOD on Real Due date +1
//		22	Go to LOG >> click on current EOD
//		23	Ensure completion of EOD on statement date
		
		// admin job
		
		
//		24	Open new internet explorer page and Enter the 'http://ecwvp3web02t.ectest.local/Prmsad04t/Root/Default.aspx' in address bar.
//		25	Login with valid username & password in Prime Issuer Web Application
//		26	"Window get opened with below options :-
//		Application Manager
//		Customer Services
//		Manual Transactions
//		Transaction Management
//		Corporate Customer
//		Security
//		Click on 'Customer Services'
//		"
//		27	Select the radio button 'Account' Enter the account number (Which is notedown earlier) in left side of the textbox &  Click on Find button
//		28	Check the account status in Financial Account Details screen.


		
		// Prime Web

	}

}
