package com.entercard.scripts;

public class ATC013_PaymentAdviceFile {

}
