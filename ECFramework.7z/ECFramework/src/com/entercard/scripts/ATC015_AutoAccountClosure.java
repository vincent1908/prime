package com.entercard.scripts;

import org.testng.annotations.Test;

import com.entercard.pages.FinancialAccountsDetail;
import com.entercard.utilities.BrowserClass;

public class ATC015_AutoAccountClosure {
	
	
	@Test
	public void NormToRem1() throws Exception {
	BrowserClass.openBrowser();
	BrowserClass.loadPrimeWebApplication();
	FinancialAccountsDetail.atc015();
	BrowserClass.closeBrowser();
	}
}
