package com.entercard.scripts;

public class ATC017_PaymentStandardTransactionFile {

}
