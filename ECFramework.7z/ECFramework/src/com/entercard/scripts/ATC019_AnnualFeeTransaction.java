package com.entercard.scripts;

public class ATC019_AnnualFeeTransaction {

}
