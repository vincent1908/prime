package com.entercard.scripts;

import org.testng.annotations.Test;

import com.entercard.pages.FinancialAccountsDetail;
import com.entercard.utilities.BrowserClass;
import com.entercard.utilities.ConfigReader;
import com.entercard.utilities.DBConnection;
import com.entercard.utilities.ProcessQuery;

public class ATC022_DisputeTransaction {

	/* ATC030 Verify the flow of making a dispute transactions. */

	@Test
	public void verifyDisputeFlow() throws Exception {
		// Step 1-4

		// 1 Click on PLSQL Developer
		// 2 Login with valid username & password by clicking under FILE
		// >>NEW>>DATABASE CONNECTION
		// 3 Run the given query in right pannel of the screen :- select * from
		// cardx where stgeneral = 'NORM'
		// 4 Notedown any cards having status as NORM and have some transactions
		// posted.
		

		DBConnection.setUpDB();
		DBConnection.runQuery(ConfigReader.prop.getProperty("FirstTestCase"));
		ProcessQuery.getAccountNumberQuery();
		DBConnection.closeDB();

		// Step 5-17

		// 5 Login with valid username & password in Prime Issuer Web
		// Application
		// 6 "Window get opened with below options :-
		// Application Manager
		// Customer Services
		// Manual Transactions
		// Transaction Management
		// Corporate Customer
		// Security
		// Click on 'Customer Services'
		// "
		// 7 Select the radio button 'card' put the account number (Which is
		// notedown earlier) in left side of the textbox & Click on Find button
		// 8 Click on 'Last 5 Transactions' and check for the date of latest
		// transaction
		// 9 Click on 'View' link against a transacion on which Dispute needs to
		// be raised.
		// 10 Click on 'Action' Dropdown option in lower right side of the
		// screen & select 'Dispute Transaction'
		// 11 "Check & fillup the below details :-
		// Amount
		// Transaction Currency
		// Transaction Type
		// Text Message
		// Reason Code
		// & click on 'Action Button'"
		// 12 Click on 'Yes(Perform Action)' button.
		// 13 Click on 'BACK' button
		// 14 Click on 'Link' at lower right side of the screen.
		// 15 Dispute Offset Adjustment transaction page should get diplayed.
		// 16 Search for the same card number again in Prime customer services
		// web application.
		// 17 Click on 'Last 5 Transactions' and check for the credit entry of
		// transaction which we have disputed earlier.

		 BrowserClass.openBrowser();
		 BrowserClass.loadPrimeWebApplication();
		 FinancialAccountsDetail.checkDispTrancFlow();
		 BrowserClass.closeBrowser();
	}

}
