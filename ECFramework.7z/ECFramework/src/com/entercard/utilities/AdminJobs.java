package com.entercard.utilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;

@SuppressWarnings("unused")
public class AdminJobs {
	static WiniumDriver driver;
	static ConfigReader configRead;

	// divide this function further
	public static void loginPrJobAdmin() throws Exception {

		DesktopOptions options = new DesktopOptions();
		// options.setApplicationPath(ConfigReader.prop.getProperty("primeAdmin"));

		options.setApplicationPath(
				"C:\\Program Files (x86)\\TSYS Card Tech\\PRIME 3.0\\PRIME Jobs Administrator\\PRIME Jobs Administrator.exe");

		try {
//			 Runtime.getRuntime().exec(ConfigReader.runWinDriver());
//			 driver = new WiniumDriver(new
//			 URL(ConfigReader.prop.getProperty("winUrl")), options);
			driver = new WiniumDriver(new URL("http://localhost:9999"), options);
			// driver.findElement(By.name("Prime Jobs Administrator")).click();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void enterAdminUserId() {
		configRead = new ConfigReader();
		String ufield = driver.findElement(By.id("txtUserName")).getText();
		for (int i = 0; i <= ufield.length(); i++) {
			driver.findElement(By.id("txtUserName")).clear();
		}
		driver.findElement(By.id("txtUserName")).sendKeys(ConfigReader.prop.getProperty("primeAdminUsername"));
		System.out.println("username pass");
	}

	public static void enterAdminPassWord() {
		configRead = new ConfigReader();
		// String pfield = driver.findElement(By.id("txtPassword")).getText();
		// for (int j = 0; j <= pfield.length(); j++) {
		// driver.findElement(By.id("txtPassword")).clear();
		// }
		// driver.findElement(By.id("txtPassword")).sendKeys(ConfigReader.prop.getProperty("primeAdminPassword"));

		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtPassword")).sendKeys(ConfigReader.prop.getProperty("primeAdminPassword"));
		System.out.println("password pass");
	}

	public static void enterAdminInstitution() {

		String ifield = driver.findElement(By.id("1001")).getText();
		for (int k = 0; k <= ifield.length(); k++) {
			driver.findElement(By.id("1001")).clear();
		}
		driver.findElement(By.id("1001")).sendKeys(ConfigReader.prop.getProperty("institution"));

	}

	public static void submitAdminActions() throws Exception {
		// click login
		driver.findElement(By.id("btnLogin")).click();
		Thread.sleep(2000);

		// click pop up
		String text = driver.findElement(By.id("65535")).getAttribute("Name");
		System.out.println(text);

		Thread.sleep(2000);
		driver.findElement(By.name("OK")).click();

		Actions action = new Actions(driver);
		WebElement element = driver.findElement(By.name("Jobs"));
		action.doubleClick(element).perform();// Double click
		driver.findElement(By.name("Scheduled")).click();
	//	Actions action1 = new Actions(driver);
		WebElement element1 = driver.findElement(By.id("trvFunctions"));
		// Right Click
		action.contextClick(element1).perform();
		driver.findElement(By.name("Submit")).click();
		driver.findElement(By.id("btnStartNext")).click();
		// driver.findElement(By.id("btnEndSubmit")).click();
		// driver.findElement(By.id("6")).click(); // Yes
		// driver.findElement(By.id("")).click(); // No
		System.out.println("Prime Job Administrator sumbit done");

		// verify if job is compeleted

		Actions action2 = new Actions(driver);
		WebElement element2 = driver.findElement(By.name("Log"));
		action2.doubleClick(element2).perform();

		// Todo -- Fetch values from Logs tree and store for further comparison

		// WebElement tree = driver.findElement(By.name("Log"));
		// List<WebElement> paysList1 = tree.findElements(By.xpath(""));

		Actions action3 = new Actions(driver);
		WebElement element3 = driver.findElement(By.name("09-05-2017"));
		action3.doubleClick(element3).perform();

		driver.findElement(By.name("End-Of-Day                    ")).click();

		driver.findElement(By.id("rdoSucceess")).isSelected();

		driver.close();
	}

}
