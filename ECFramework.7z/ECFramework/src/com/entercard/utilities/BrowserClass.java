package com.entercard.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class BrowserClass extends ProcessQuery {

	public static WebDriver driver;
	static ConfigReader configRead;

	public BrowserClass(WebDriver driver) {
		driver = BrowserClass.driver;
	}

	/* Need to work on Gecko Driver and IE Driver */

	// public static void openFirefoxBrowser() throws Exception {
	// driver = new FirefoxDriver();
	// driver.manage().window().maximize();
	// Thread.sleep(30000);
	// System.out.println("=====Browser Session Started=====");
	// }

	public static void openBrowser() {
		// System.out.println("launching chrome browser");
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\repository\\ECFramework\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();

	}

	public static void openBrowser(String browserType) {
		switch (browserType) {
		case "firefox":
			System.setProperty("webdriver.gecko.driver", "C:\\Selenium\\repository\\ECFramework\\lib\\geckodriver.exe");

			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			break;
		case "chrome":
			System.setProperty("webdriver.chrome.driver",
					"C:\\Selenium\\repository\\ECFramework\\lib\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			break;
		case "IE":
			System.setProperty("webdriver.ie.driver", "C:\\Selenium\\repository\\ECFramework\\lib\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			driver.manage().window().maximize();

			break;
		default:
			System.setProperty("webdriver.chrome.driver",
					"C:\\Selenium\\repository\\ECFramework\\lib\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
		}

	}

	/*
	 * Not used after test case 4
	 */
	public static void loadPrimeWebApplication() {
		configRead = new ConfigReader();
		driver.get(ConfigReader.prop.getProperty("PrimeCustomerServices5"));
	}

	public static void loadPrimeWebApplication1(String url) {
		driver.get(url);
	}

	public static void closeBrowser() throws InterruptedException {
		Thread.sleep(5000);
		driver.quit();
		// System.out.println("=====Browser Session End=====");

	}

	public static void checkAccNum() {
		System.out.println(accNum);
	}
}
