package com.entercard.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ConfigReader {

	public static Properties prop;

	public ConfigReader() {

		try {
			// Specify the file location I used . operation here because
			// we have object repository inside project directory only
			File src = new File(
					"C:\\Selenium\\repository\\ECFramework\\src\\com\\entercard\\properties\\dataFile.properties");

			// Create FileInputStream object
			FileInputStream fis = new FileInputStream(src);
			// Create Properties class object to read properties file
			prop = new Properties();
			// Load file so we can use into our script
			prop.load(fis);
			System.out.println("Property class loaded");
		} catch (Exception e) {

			System.out.println("Exception is : " + e.getMessage());
		}

	}

	/*
	 * Common functions
	 */

	public static String runWinDriver() {
		String wdPath = prop.getProperty("scriptPath");
		return wdPath;
	}

}
