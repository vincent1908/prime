package com.entercard.utilities;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.entercard.framework.LoadPropertyFile;

public class DBConnection {

	private static java.sql.Connection connection;
	private static java.sql.Statement statement;
	public static java.sql.ResultSet rs;

	static ConfigReader con;
	protected static String accNum = "";

	static LoadPropertyFile lp;

	public static void setUpDB() {
		con = new ConfigReader();

		String databaseURL = ConfigReader.prop.getProperty("databaseURL");
		String user = ConfigReader.prop.getProperty("dbUserName");
		String password = ConfigReader.prop.getProperty("dbPassword");

		//
		connection = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Connecting to Database...");
			connection = DriverManager.getConnection(databaseURL, user, password);
			if (connection != null) {
				System.out.println("Connected to the Database");
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		}
	}

	/* Not Used */

	public static void setupDatabase(String dbURL, String dbUN, String dbPW) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(dbURL, dbUN, dbPW);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static ResultSet runQuery(String query) {

		try {
			statement = connection.createStatement();
			rs = statement.executeQuery(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rs;
	}

	/* Not Used */

	public static String executeQuery(String query, String columnValue) {

		try {
			statement = connection.createStatement();
			rs = statement.executeQuery(query);
			while (rs.next()) {
				accNum = rs.getString(columnValue);
				// System.out.println(accNum);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return accNum;
	}

	public static void closeDB() {
		if (connection != null) {
			try {
				connection.close();
				System.out.println("Database Connection Closed");
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	// public static void main(String[] args){
	// setUpDB();
	// runQuery("SELECT * from CACCOUNTS WHERE stgeneral in ('CLSD','DCAC')AND
	// ROWNUM <= 1");
	// closeDB();
	// }
}
