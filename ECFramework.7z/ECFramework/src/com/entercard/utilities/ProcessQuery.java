package com.entercard.utilities;

import java.sql.SQLException;

public class ProcessQuery extends DBConnection {
	public static String accNum = null;
	public static String accNum1 = null;
	public static String accNum2 = null;


	// public class ProcessQuery extends DatabaseConnection {
	public static String getAccountNumberQuery() {
		try {
			while (rs.next()) {

				accNum = rs.getString("NUMBERX");

				System.out.println("Customer Acccount Number is : " + accNum);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return accNum;
	}
	
	public static String getAccountNumberQueryClosed() {
		try {
			while (rs.next()) {

				accNum = rs.getString("NUMBERX");

				System.out.println("Customer Acccount Number is : " + accNum1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return accNum1;
	}
	
	public static String getAccountNumberQueryNorm() {
		try {
			while (rs.next()) {

				accNum = rs.getString("NUMBERX");

				System.out.println("Customer Acccount Number is : " + accNum2);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return accNum2;
	}
	
	/*Not Used*/
	
	public static String getAccountNumberQuerya(String columnName) {
		try {
			while (rs.next()) {

				accNum = rs.getString(columnName);

				System.out.println("Customer Acccount Number is : " + accNum);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return accNum;
	}

	// public static String Todo() {
	// try {
	// while (rs.next()) {
	//
	// accNum = rs.getString("NUMBERX");
	//
	// System.out.println("Customer Acccount Number is : " + accNum);
	// }
	// } catch (SQLException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	//
	// return accNum;
	// }

	public static void main(String[] args) {
		setUpDB();
		runQuery("SELECT * from CACCOUNTS WHERE stgeneral in ('CLSD','DCAC')AND ROWNUM <= 1");
		getAccountNumberQuery();
		closeDB();

	}

}
